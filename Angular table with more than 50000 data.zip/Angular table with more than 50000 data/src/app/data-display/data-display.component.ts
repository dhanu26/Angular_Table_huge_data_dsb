import { Component, OnInit } from '@angular/core';
import { DataserviceService } from '../dataservice.service';

@Component({
  selector: 'app-data-display',
  templateUrl: './data-display.component.html',
  styleUrls: ['./data-display.component.css']
})
export class DataDisplayComponent implements OnInit {

  constructor(private ds: DataserviceService) { }

  ngOnInit(): void {
    this.fetchDetails();
  }
  userdata: any[]=[];
  errorMessage: any;
  collection: any[] = ['a', 'b', 'c', 'd'];
  startvalue: number = 0;
  endvalue: number = 0;
datarange:number[]=[];
interval:number=20;

  prev() {
    this.startvalue -= this.interval;
  }
  next() {
    this.startvalue += this.interval;
  }


  loadspecificPage(n:number){
    if(n<=0)
    this.startvalue=0;
    else   
    this.startvalue=this.interval*(n-1);
  }

  fetchDetails() {
    // console.log("hello");

    this.ds.fetchdata().subscribe(res => {
      this.userdata = res.data;
      this.endvalue=res.data.length;
      // console.log(this.userdata);
      for (let l= 0; l < this.endvalue/this.interval; l++) {
        this.datarange.push(l+1);
      }
    }, err => {
      this.errorMessage = err;
      console.log("Connection error");
    })
  }
}
