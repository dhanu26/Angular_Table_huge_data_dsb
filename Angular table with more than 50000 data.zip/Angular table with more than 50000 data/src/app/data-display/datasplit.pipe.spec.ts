import { DatasplitPipe } from './datasplit.pipe';

describe('DatasplitPipe', () => {
  it('create an instance', () => {
    const pipe = new DatasplitPipe();
    expect(pipe).toBeTruthy();
  });
});
