import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'datasplit'
})
export class DatasplitPipe implements PipeTransform {

  transform(values: any[], ...args: number[]): any {
    return null;
  }

}
