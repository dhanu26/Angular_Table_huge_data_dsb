import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DataserviceService {
url:string="https://walkwel.herokuapp.com/";
  constructor(private http:HttpClient) { }

  fetchdata():Observable<any>{
return this.http.get<any>(this.url);
  }
}
